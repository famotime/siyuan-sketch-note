# Sketch Note (闲笔)

思源笔记手写插件，支持在文档中嵌入手写笔记。

插件标识：`siyuan-sketch-note`。

## 功能特性

- 手写输入：使用触控笔或手指在 Canvas 画布上书写
- 矢量笔迹：笔迹以矢量数据存储，支持无损二次编辑
- 最近颜色槽：内置常用颜色，可通过颜色选择器加入自定义颜色
- 荧光笔：支持半透明标注效果
- 工具预设：画笔、荧光笔、橡皮分别记忆粗细和透明度
- 编辑器快捷键：支持保存、撤销、重做和常用工具切换
- 误触防护：支持“仅触控笔”模式，手指触摸不再产生笔迹
- 橡皮擦：支持像素级精确擦除和整笔擦除
- 形状工具：支持直线、箭头、矩形、椭圆、三角形
- 套索编辑：支持自由套索和矩形框选，选区可移动、缩放、复制、删除和改色
- 混合内容：支持可编辑文本框，支持插入或粘贴图片，图片可移动、缩放，并可继续手写标注
- 撤销 / 重做：完整的历史操作栈
- 9 种模板：白纸、方格纸、横线纸、点阵纸、康奈尔笔记、会议记录、待办清单、周计划、月计划
- 自定义背景：可导入图片作为手写页背景，用于图片/PDF 截图标注场景
- 自动增长：写到底部时画布自动扩展
- 页面导航：顶部显示当前页/总页数，可新增、复制、删除空白页面，为多页笔记和分页导出打基础
- PNG 导出：可将当前页导出为图片，分页文档会自动带上页码
- PDF 导出：按画布高度自动分页导出多页 PDF，可选择是否包含背景模板
- JSON 备份/恢复：可导出并重新导入手写块源数据，便于迁移、诊断和恢复
- 搜索基础：预留 OCR 文本索引结构，可按识别文本定位到手写块与具体页面
- OCR 文字识别（实验性）：支持识别当前页手写文字，识别后可在块内搜索定位，隐私优先，默认不发送用户数据
- 性能基础：笔迹保存时预计算边界，便于后续局部重绘、检索和大文档优化
- DPI 适配：高分屏（iPad Retina 等）笔迹清晰
- 明暗主题：跟随思源笔记主题
- 中英双语

## 使用方法

1. 点击顶栏手写笔图标，或按 `Ctrl+Shift+S` 插入手写块
2. 在全屏编辑器中书写
3. 点击保存或返回，缩略图自动嵌入文档
4. 点击文档中的缩略图可再次编辑

编辑器内可使用 `Ctrl/Cmd+S` 保存，`Ctrl/Cmd+Z` 撤销，`Ctrl/Cmd+Shift+Z` 或 `Ctrl/Cmd+Y` 重做，数字键 `1` 到 `7` 切换画笔、荧光笔、橡皮、套索、箭头和三角形。

### OCR 文字识别（实验性）

手写笔记支持 OCR 识别手写文字。该功能**隐私优先**：默认 provider 不发送任何数据到外部服务。

1. 在手写编辑器中书写内容
2. 点击顶栏「识别文字」按钮，等待识别完成
3. 点击「搜索」按钮，输入关键词即可在手写内容中搜索
4. 搜索结果会高亮显示并自动跳转到对应页面

如需接入真实 OCR 引擎，可通过 `ocrProvider` 属性注入自定义 provider：

```ts
import type { OcrProvider } from "siyuan-sketch-note/src/search/ocrProvider";

const myProvider: OcrProvider = async (input) => {
  // 将 input.imageBlob 发送到你的 OCR 服务
  // 返回 OcrLine[]，包含 text、confidence 和 bounds
};
```

## 开发

```bash
pnpm install
pnpm dev    # 开发模式（watch）
pnpm test   # 运行单元测试
pnpm build  # 生产构建
```

`pnpm dev` 会读取 `.env` 中的 `VITE_SIYUAN_WORKSPACE_PATH`，并将插件构建到：

```text
{思源工作空间}/data/plugins/siyuan-sketch-note
```

`pnpm build` 会生成 `dist/` 和 `package.zip`，其中 `plugin.json` 的 `name` 为 `siyuan-sketch-note`，安装后的插件目录也应使用该名称。

## 技术栈

- Vue 3 + TypeScript
- HTML5 Canvas 2D + Pointer Events API
- SiYuan Plugin SDK
- Vite
